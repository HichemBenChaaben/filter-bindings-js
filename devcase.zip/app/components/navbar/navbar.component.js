(function() {
  'use strict';
  angular.module('testApp')
    .component('navbarComponent', {
      templateUrl: 'components/navbar/navbar.html'
    });
})();
