(function() {
  'use strict';
  angular.module('testApp')
    .component('loaderComponent', {
      templateUrl: 'components/loader/loader.html'
    });
})();
