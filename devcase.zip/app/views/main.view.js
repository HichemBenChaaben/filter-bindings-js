(function() {
  'use strict';
  angular.module('testApp')
    .component('mainView', {
      templateUrl: 'views/main.html'
    });
})();
