### Install dependencies and view the project files

#### Install project dependencies
simply run ```npm install```
then run ```bower install```

#### Run the application
Once the dependencies installed, run 
```
npm run build
```
This will run a preview of the production ready code

To run the dev mode

```
gulp
```
This will run Browsersync, will watch assets, and will autoreload on file changes

